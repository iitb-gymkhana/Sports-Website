<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * Model for admins
 * @property string $ldap
 * @property string $type
 */
class Admin extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			['ldap', 'required'],
			[['ldap', 'string'], 'string']
		];
	}
}