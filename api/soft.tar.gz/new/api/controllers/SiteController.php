<?php
namespace api\controllers;

use api\components\ApiController;
use yii\filters\auth\HttpBearerAuth;
use yii\web\Response;
use yii\filters\AccessControl;

/**
 * Site controller
 */
class SiteController extends ApiController
{
    /**
     * {@inheritdoc}
     */
    public function actionError()
    {
        // Do nothing
    }

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['access']['rules'] = [['allow' => true, 'roles' => ['?','@']]];
        $behaviors['authenticator']['optional'] = ['test'];

        return $behaviors;
    }

    /**
     * Testing endpoint
     */
    public function actionTest(){
    	return [
    		'isGuest' => \Yii::$app->user->isGuest,
    		'isAdmin' => \Yii::$app->user->isAdmin
    	];
    }
}