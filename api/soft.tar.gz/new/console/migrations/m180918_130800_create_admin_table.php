<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_admin`.
 */
class m180918_130800_create_admin_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_admin', [
            'ldap' => $this->string(),
            'type' => $this->string(),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_admin', 'ldap');

        // add foreign key for table `admin` to reference `users`
        $this->addForeignKey(
            'fk-admin_ldap-event',
            'api_admin', 'ldap',
            'api_users', 'ldap',
            'CASCADE'
        );

        // pre-fill table with some values
        $this->batchInsert('api_admin', ['ldap', 'type'], [
            ['aquatics', 'secretary'],
            ['athletics', 'secretary'],
            ['badminton', 'secretary'],
            ['basketball', 'secretary'],
            ['boardgames', 'secretary'],
            ['cricket', 'secretary'],
            ['football', 'secretary'],
            ['hockey', 'secretary'],
            ['indiangames', 'secretary'],
            ['lawntennis', 'secretary'],
            ['squash', 'secretary'],
            ['tabletennis', 'secretary'],
            ['volleyball', 'secretary'],
            ['weightlifting', 'secretary'],
            ['gsecsports', 'admin'],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-admin_ldap-event',
            'api_admin'
        );

        $this->dropTable('api_admin');
    }
}
