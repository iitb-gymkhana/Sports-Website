<?php

return array_merge(
	[
	    'class' => 'core\models\NamedConnection',
	    'dbName' => 'iitb_sports',
	    'dsn' => 'mysql:host=127.0.0.1;dbname=iitb_sports'
	],
	require __DIR__ . '/database-login.php'
);