<?php

namespace api\controllers;

use Yii;
use api\components\ApiRestController;
use yii\web\ConflictHttpException;
use yii\web\ForbiddenHttpException;
use yii\web\NotFoundHttpException;

/**
 * Controller for the club model
 */
class LadderResultController extends ApiRestController
{
    /**
     * @var yii\db\ActiveRecord model for storing ladder match information
     */
    public $modelClass = 'api\models\LadderResult';
    
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['authenticator']['except'] = ['index', 'view', 'options'];
        $behaviors['access']['rules'] = [
            ['allow' => true, 'actions' => ['index', 'view', 'options'], 'roles' => ['?']],
            ['allow' => true,  'roles' => ['@']],
        ];
        return $behaviors;
    }

    /**
     * {@inheritdoc}
     */
    public function checkAccess($action, $model = null, $params = [])
    {
        // Allow all actions for admins
        if(Yii::$app->user->isAdmin)    return;

        // Allow only players to add a match
        if($action === 'create') {
            $newModel = Yii::$app->getRequest()->getBodyParams();

            $match = \api\models\LadderMatch::findOne($newModel['match_id']);
            if($match === null)
                throw new NotFoundHttpException("No match found");

            $winner = $newModel['winner'] === 'challenger' ? $match->challenger : $match->opponent;
            $loser = $newModel['winner'] !== 'challenger' ? $match->challenger : $match->opponent;
            if(Yii::$app->user->id !== $winner && Yii::$app->user->id !== $loser)
                throw new ForbiddenHttpException("Players are allowed to post only their own match results");
        }

        $match = \api\models\LadderMatch::findOne($model->match_id);
        $winner = $match->opponent === $model->winner ? $match->opponent : $match->challenger;
        $loser = $match->opponent === $model->winner ? $match->challenger : $match->opponent;

        // Allow player to modify only his confirmation of result
        if($action === 'update') {
            if(Yii::$app->user->id !== $winner && Yii::$app->user->id !== $loser)
                throw new ForbiddenHttpException("Only players and admins are allowed to modify match details");

            if($model->winner_confirmation !== null && $model->loser_confirmation !== null)
                throw new ForbiddenHttpException("You have already confirmed the match result");
        }

        // Only players and admins are allowed delete operations
        if($action === 'delete') {
            if(Yii::$app->user->id !== $winner && Yii::$app->user->id !== $loser)
                throw new ForbiddenHttpException("Only players and admins are allowed to delete a match request");

            // If the player who made the entry wishes to delete the entry, allow the action
            if(Yii::$app->user->id === $winner && $model->winner_confirmation !== null && $model->loser_confirmation === null)
                return;
            if(Yii::$app->user->id === $loser && $model->loser_confirmation !== null && $model->winner_confirmation === null)
                return;

            if($model->loser_confirmation !== null && $model->winner_confirmation === null)
                throw new ConflictHttpException("Match result has been seen upon by both parties. Contact the administrator to resolve this issue.");

            throw new ConflictHttpException("You can only accept/reject the match result");
        }
    }
}
