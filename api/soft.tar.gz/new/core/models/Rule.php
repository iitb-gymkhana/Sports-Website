<?php

namespace core\models;

use yii\db\ActiveRecord;

/**
 * Model for club facilities
 * @property string $club
 * @property string $rule
 */
class Rule extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['club', 'rule'], 'required'],
			[['club', 'rule'], 'string']
		];
	}
}