<?php

namespace core\models;

use yii\db\ActiveRecord;

/**
 * Model for club page details
 * @property string $club
 * @property string $description
 */
class ClubDetail extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['club', 'description'], 'required'],
			[['club', 'description'], 'string']
		];
	}

	/**
	 * @inheritdoc
	 */ 
	public static function tableName()
	{
		return 'club_detail';
	}
}