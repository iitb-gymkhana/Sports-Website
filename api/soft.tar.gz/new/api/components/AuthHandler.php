<?php

namespace api\components;

use yii\authclient\ClientInterface;
use api\models\Token;
use api\models\UserDetail;
use api\models\UserContact;
use api\models\UserEmail;

/**
 * AuthHandler handles successful authentication via Yii auth component
 * 
 * @property yii\authclient\ClientInterface $client ClientInterface instance
 * @property yii\authclient\OAuthToken $token Corresponding OAuth Token instance
 */
class AuthHandler
{
    /**
     * @var ClientInterface
     */
    private $client;
	
	/**
     * @var OAuthToken
     */
    private $token;    

    /**
     * {@inheritdoc}
     */
    public function __construct(ClientInterface $client)
    {
        $this->client = $client;
        $this->token = $client->getAccessToken();
    }

	/**
     * Update records for authenticated client in backend
     */
    public function handle()
	{
		$this->updateUserInfo();
        $this->saveTokenInfo();
	}

	/**
     * Save new api\models\Token instance based on client credentials
     *
     * @see api\models\Token
     */
    protected function saveTokenInfo()
	{
		$attributes = $this->client->getUserAttributes();
		$tokenParams = $this->token->getParams();

		$user_token = new Token;
        $user_token->ldap = $attributes['roll_number'];
        $user_token->access_token = $tokenParams['access_token'];
        $user_token->refresh_token = $tokenParams['refresh_token'];
        $user_token->expires_in = $tokenParams['expires_in'];
        $user_token->created_at = date('Y-m-d H:i:s', $this->token->createTimestamp);
        $user_token->scope = $tokenParams['scope'];  
        $user_token->save();
	}

	/**
     * Update user records based on data from resource endpoint of SSO
     *
     * @see api\models\UserDetail
     * @see api\models\UserEmail
     * @see api\models\UserContact
     */
    protected function updateUserInfo()
	{
		$attributes = $this->client->getUserAttributes();

		$user_details = UserDetail::findOne($attributes['roll_number']);
        if($user_details == null)   $user_details = new UserDetail;
        $user_details->ldap = $attributes['roll_number'];
        $user_details->first_name = $attributes['first_name'];
        $user_details->last_name = $attributes['last_name'];
        $user_details->sex = $attributes['sex'];
        $user_details->type = $attributes['type'];
        $user_details->hostel = $attributes['insti_address']['hostel'];
        $user_details->graduation_year = $attributes['program']['graduation_year'];
        $user_details->join_year = $attributes['program']['join_year'];
        $user_details->degree = $attributes['program']['degree'];
        $user_details->department = $attributes['program']['department'];
        $user_details->save();

        $user_contact = UserContact::findOne(
            ['ldap' => $attributes['roll_number'], 'mobile' => $attributes['mobile']]
        );
        if($user_contact == null) {
            $user_contact = new UserContact;
            $user_contact->ldap = $attributes['roll_number'];
            $user_contact->mobile = $attributes['mobile'];
            $user_contact->save();
        }
        foreach($attributes['contacts'] as $key => $value) {
            $user_contact = UserContact::findOne(
                ['ldap' => $attributes['roll_number'], 'mobile' => $value['number']]
            );
            if($user_contact == null)   $user_contact = new UserContact;
            else    continue;
            $user_contact = new UserContact;
            $user_contact->ldap = $attributes['roll_number'];
            $user_contact->mobile = $value['number'];
            $user_contact->save();
        }

        $user_email = UserEmail::findOne(
            ['ldap' => $attributes['roll_number'], 'email' => $attributes['email']]
        );
        if($user_email == null) {
            $user_email = new UserEmail;
            $user_email->ldap = $attributes['roll_number'];
            $user_email->email = $attributes['email'];
            $user_email->save();
        }
        foreach ($attributes['secondary_emails'] as $key => $value) {
            $user_email = UserEmail::findOne(
                ['ldap' => $attributes['roll_number'], 'email' => $value['email']]
            );
            if($user_email == null)    $user_email = new UserEmail;
            else    continue;
            $user_email->ldap = $attributes['roll_number'];
            $user_email->email = $value['email'];
            $user_email->save();
        }
	}
}