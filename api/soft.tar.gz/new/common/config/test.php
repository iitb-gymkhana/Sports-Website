<?php

$config =  yii\helpers\ArrayHelper::merge(
    require(__DIR__ . '/main.php'),
    [
        'id' => 'common-tests',
    ]
);

return $config;