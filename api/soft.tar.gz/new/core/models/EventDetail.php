<?php

namespace core\models;

use yii\db\ActiveRecord;
use Event;

/**
 * Model for details of an event
 * @property string $id unique ID for the event
 * @property string $event ID of the event (foreign key)
 * @property string $title Tag/title
 * @property string $headline text for news headline
 * @property datetime $startTime
 * @property datetime $endTime
 * @property bool $showOnlyDate
 * @property text $brief event at a brief glance
 * @property text $content details of the event
 */
class EventDetail extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['id', 'startTime', 'headline', 'brief'], 'required'],
			[['endTime'], 'default', 'value' => null],
			
		];
	}

	/**
	 * @inheritdoc
	 */ 
	public static function tableName()
	{
		return 'event_detail';
	}
}