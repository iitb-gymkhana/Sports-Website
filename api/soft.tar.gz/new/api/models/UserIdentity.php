<?php
namespace api\models;

use Yii;
use yii\base\NotSupportedException;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;
use yii\web\IdentityInterface;
use api\models\Admin;
use api\models\Token;
use yii\authclient\OAuthToken;

/**
 * User model
 * Authentication using OAuth2.0 only - no other authentication methods (including cookies)
 *
 * @property string $ldap LDAP of user
 * @property string $access_token access token for OAuth2.0 of user
 * @property string $refresh_token refresh token for OAuth2.0 of user
 * @property integer $expires_in expiration time of access token
 * @property string $created_at time when access token was generated
 * @property string $scope allowed scopes for the user
 */
class UserIdentity extends ActiveRecord implements IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return '{{%users}}';
    }

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::className(),
                'attributes' => [
                    ActiveRecord::EVENT_BEFORE_INSERT => ['created_at']
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        return static::findOne($id);
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null)
    { 
        $user_token = Token::findOne(['access_token' => $token]);
        if($user_token == null) return null;

        $token = new \yii\authclient\OAuthToken([
            'createTimestamp' => strtotime($user_token->created_at),
            'tokenParamKey' => 'access_token'
        ]);
        $token->setParams([
            'access_token' => $user_token->access_token,
            'refresh_token' => $user_token->refresh_token,
            'expires_in' => $user_token->expires_in,
            'scope' => $user_token->scope,
            'token_type' => 'Bearer'
        ]);

        if(!$token->getIsValid()){
            return null;
        }
        
        return static::findOne($user_token->ldap);
    }

    public static function loginByAccessToken($token, $type = null)
    {
        return static::findIdentityByAccessToken($token, $type);
    }

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->getPrimaryKey();
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey()
    {
        throw new NotSupportedException('"getAuthKey" is not implemented.');
    }

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        throw new NotSupportedException('"validateAuthKey" is not implemented.');
    }
}
