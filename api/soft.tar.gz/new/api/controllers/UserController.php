<?php
namespace api\controllers;

use api\components\ApiRestController;

/**
 * Controller for obtaining information about user
 */
class UserController extends ApiRestController
{
	/**
     * {@inheritdoc}
     */
    public $modelClass = 'api\models\UserDetail';

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
    	$behaviors = parent::behaviors();
    	$behaviors['authenticator']['except'] = ['options'];
    	// Allow guests to see their privelege levels by not enforcing authentication
    	$behaviors['authenticator']['optional'] = ['privelege-level'];

        $behaviors['access']['rules'] = [
        	// Allow only institute citizens to make these queries
        	['allow' => false, 'roles' => ['?'], 'actions' => ['update', 'index', 'view']],
        	// Allow guests and authenticated users alike for other controllers
        	['allow' => true, 'roles' => ['?', '@']]
        ];
        return $behaviors;
    }
    
    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        $actions = parent::actions();
        // disable [create, update and delete] actions
        unset($actions['create'], $actions['delete']);

        return $actions;
    }

    /**
     * {@inheritdoc}
     */
    public function verbs()
    {
        $verbs = parent::verbs();
        $verbs['privelege-level'] = 'GET';
        return $verbs;
    }

    /**
     * Get the privelege level of the user, i.e., whether the user is a guest or an admin
     * or neither
     *
     * @return array privelege levels of user
     */
    public function actionPrivelegeLevel()
    {
    	return [
    		'guest' => \Yii::$app->user->isGuest,
    		'admin' => \Yii::$app->user->isAdmin,
    	];
    }

    /**
     * {@inheritdoc}
     */
    public function checkAccess($action, $model = null, $params = [])
    {
    	if($action === 'update') {
    		if(\Yii::$app->user->id !== $model->ldap)
    			throw new \yii\web\ForbiddenHttpException("You can change only your own profile details");
    	}
    }
}