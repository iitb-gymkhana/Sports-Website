<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_user_email`.
 */
class m181018_055943_create_user_emails_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_user_email', [
            'ldap' => $this->string()->notNull(),
            'email' => $this->string()->notNull()
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_user_email', ['ldap', 'email']);

        $this->addForeignKey(
            'fk-user_emails_ldap-event',
            'api_user_email', 'ldap',
            'api_users', 'ldap',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-user_emails_ldap-event',
            'api_user_email'
        );

        $this->dropTable('api_user_email');
    }
}
