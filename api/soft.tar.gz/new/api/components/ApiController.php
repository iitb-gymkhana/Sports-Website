<?php
namespace api\components;

use yii\web\Controller;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\AccessControl;
use yii\filters\ContentNegotiator;
use yii\web\Response;

/**
 * ApiController
 * Standard controller class for API application
 *
 * Authenticates using yii\filters\auth\HttpBearerAuth and uses yii\filters\AccessControl
 * Modify behavior in instances of ApiController to exempt actions from authentication and
 * add rules for access control
 */
class ApiController extends Controller
{
	/**
     * {@inheritdoc}. Added authenticator and access controls to the controller, 
     * whose rules need to explicitly specified in the instances of ApiRestController.
     *
     * Example:
     * ```
     *	$behaviors = parent::behaviors();
     *	$behaviors['access']['rules'] = [
     *		// add custom rules (instance of yii\filters\AccessRule) here ...
     *		['allow' => false, 'ips' => '10.3.*'],
     *		// you can also use custom classes
     *	];
     *	$behaviors['authenticator'] = [
     *		// add custom authenticator properties here ...
     *	];
     * ```
	 *
	 * @see yii\filters\AccessRule
	 * @see yii\filters\auth\HttpBearerAuth
     */
    public function behaviors()
	{
		$behaviors = parent::behaviors();
		$access = [
			'class' => AccessControl::className(),
			'denyCallback' => function ($rule, $action) {
                throw new \Exception('Insufficient priveleges to access this page');
            },

			/* Modify this parameter in the instance
			 * Array of yii\filters\AccessRule - configure access control rules
			 */
			'rules' => [['allow' => true, 'roles' => ['@']]],
		];

		$authenticator = [
			'class' => HttpBearerAuth::className(),
			
			/* Modify this parameter in the instance
			 * Array of action IDs exempt from authentication
			 */
			'except' => [],
			
			/* Modify this parameter in the instance
			 * Array of action IDs which are to be executed irregardless of authentication failure
			 */
			'optional' => [],
		];

		$contentNegotiator = [
            'class' => ContentNegotiator::className(),
            'formats' => ['application/json' => Response::FORMAT_JSON],
        ];

        $behaviors = parent::behaviors();
        unset($behaviors['authenticator'], $behaviors['access'], $behaviors['contentNegotiator']);
        // Authenticator behavior should run first
        $behaviors['authenticator'] = $authenticator;
        $behaviors['access'] = $access;
        $behaviors['contentNegotiator'] = $contentNegotiator;
        
        return $behaviors;
	}
}