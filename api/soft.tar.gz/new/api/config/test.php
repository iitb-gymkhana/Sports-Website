<?php

$config =  yii\helpers\ArrayHelper::merge(
    require(__DIR__ . '/main.php'),
    [
	    'id' => 'api-tests',
	],
	require(__DIR__ . '/test-local.php')
);

return $config;
