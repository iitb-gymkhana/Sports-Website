<?php

use yii\db\Migration;

/**
 * Handles dropping access_token from table `api_users`.
 */
class m181018_063818_drop_access_token_column_from_users_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('api_users', 'access_token');
        $this->dropColumn('api_users', 'created_at');
        $this->dropColumn('api_users', 'updated_at');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->addColumn('api_users', 'access_token', $this->string()->unique());
        $this->addColumn('api_users', 'created_at', $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'));
        $this->addColumn('api_users', 'updated_at', $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'));
    }
}
