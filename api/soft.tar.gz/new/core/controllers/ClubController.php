<?php

namespace core\controllers;

use yii\rest\ActiveController;
use yii\web\BadRequestHttpException;
use yii\helpers\Url;

/**
 * Controller for the club model
 */
class ClubController extends ActiveController
{
    public $modelClass = 'core\models\Club';

    public function action()
    {
        $actions = parent::actions();
        // disable [create, update and delete] actions
        unset($actions['create'], $actions['update'], $actions['delete']);

        return $actions;
    }
}
