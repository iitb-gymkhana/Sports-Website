<?php

namespace core\models

use yii\db\ActiveRecord;

/**
 * Model for keeping track of registrations across events
 * @property string $event event ID
 * @property string $ldap LDAP of registering person
 * @property datetime $time time of registration
 * @property boolean $paid whether amount has been paid
 */
class Registration extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['event', 'ldap', 'time'], 'required'],
			[['paid'], 'default', 'value' => false]
		];
	}
}