<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * Token model
 * OAuth2.0 Token
 *
 * Custom model for OAuth2.0 token model. This is meant to be used only for accessiblity
 * and storage purposes. For authentication, create a new yii\authclient\OAuthToken instance
 * using properties of this class.
 *
 * @property integer $ldap LDAP of user
 * @property string $access_token access token for OAuth2.0 of user
 * @property string $refresh_token refresh token for OAuth2.0 of user
 * @property integer $expires_in expiration time of access token
 * @property string $created_at time when access token was generated
 * @property string $scope allowed scopes for the user
 */
class Token extends ActiveRecord
{
	/**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ldap', 'access_token', 'refresh_token', 'scope', 'created_at'], 'string'],
            ['expires_in', 'integer']
        ];
    }

    /**
     * Populate current class with authorisation header (HTTP Bearer Authentication)
     *
     * @see yii\filters\auth\HttpBearerAuth
     */
    public function initialise()
    {
        $header = 'Authorization';
        $pattern = '/^Bearer\s+(.*?)$/';
        $authHeader = \Yii::$app->request->getHeaders()->get($header);

        if ($authHeader !== null) {
            if (preg_match($pattern, $authHeader, $matches)) {
                $authHeader = $matches[1];
            }
            
            $token = static::findOne(['access_token' => $authHeader]);
            foreach($this->attributes() as $k => $value) {
                $this->$value = $token->$value;
            }
        }
    }

    /**
     * Get yii\authclient\OAuthToken instance from current properties of class
     *
     * @return yii\authclient\OAuthToken OAuth Token retrieved from authorization header
     */
    public function getOauthToken()
    {
        if($this->ldap == null) return null;

        $token = new \yii\authclient\OAuthToken([
            'createTimestamp' => strtotime($this->created_at),
            'tokenParamKey' => 'access_token',
            'expireDurationParamKey' => 'expires_in'
        ]);
        $token->setParams([
            'access_token' => $this->access_token,
            'refresh_token' => $this->refresh_token,
            'expires_in' => $this->expires_in,
            'scope' => $this->scope,
            'token_type' => 'Bearer'
        ]);

        return $token;
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
    	return '{{%user_tokens}}';
    }

    /**
     * Get status of access token used in authorisation header - 'expired',
     * 'invalid', or 'valid'. The access token is deleted from the records
     * if expired
     *
     * @return string status of current access token
     */
    public function getStatus()
    {
        $user = \Yii::$app->user;
        $status = 'invalid';

        $this->initialise();
        $token = $this->getOauthToken();

        if($token->getIsExpired()){
            $status = 'expired';
            $this->delete();
        }
        else
            $status = 'valid';

        return $status;
    }

    /**
     * Get a new access token from the OAuth server using access token
     * in current authorization header and delete old token record
     *
     * @return api\models\Token a new Token model instance
     */
    public function refresh()
    {
        $this->initialise();
        $token = $this->getOauthToken();

        if($token == null)  return null;

        $oauth = new \api\components\SSO;
        $oauth->setAccessToken($token);
        try {
            $newToken = \Yii::$app->authClientCollection->getClient('sso')->refreshAccessToken($token);
            $newTokenParams = $newToken->getParams();

            $newModel = new Token;
            $newModel->ldap = $this->ldap;
            $newModel->access_token = $newTokenParams['access_token'];
            $newModel->refresh_token = $newTokenParams['refresh_token'];
            $newModel->created_at = date('Y-m-d H:i:s', $newToken->createTimestamp);
            $newModel->expires_in = $newTokenParams['expires_in'];
            $newModel->scope = $newTokenParams['scope'];
            $newModel->save();

            $oldModel = static::findOne(['access_token' => $this->access_token]);
            // Need to delete this record
            // Cannot use $this->delete() - unable to delete
            if($oldModel->delete() == false)
                throw \Exception("Unable to delete record");

            return $newModel;
        } catch (\yii\authclient\InvalidResponseException $e) {
            return null;
        }
    }
}