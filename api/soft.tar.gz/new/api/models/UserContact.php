<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * User contact model
 * Store multiple mobile numbers of a user
 *
 * @property string $ldap LDAP of user
 * @property string $mobile mobile number of user
 */
class UserContact extends ActiveRecord
{
	/**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ldap', 'mobile'], 'required'],
            ['ldap', 'string'],
            ['mobile', 'integer']
        ];
    }
}