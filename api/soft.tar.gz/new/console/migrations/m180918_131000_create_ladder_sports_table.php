<?php

use yii\db\Migration;

/**
 * Handles the creation of table `ladder_sports`.
 */
class m180918_131000_create_ladder_sports_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_ladder_sports', [
            'club' => $this->string(),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_ladder_sports', 'club');

        // add foreign key for table `ladder_sports` to reference `club`
        $this->addForeignKey(
            'fk-ladder_sports_club-event',
            'api_ladder_sports', 'club',
            'api_club', 'id',
            'CASCADE'
        );

        // pre-fill table with some values
        $this->batchInsert('api_ladder_sports', ['club'], [
            ['badminton'],
            ['lawntennis'],
            ['squash'],
            ['tabletennis'],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-ladder_sports_club-event',
            'api_ladder_sports'
        );

        $this->dropTable('api_ladder_sports');
    }
}
