<?php

namespace core\models;

use yii\db\ActiveRecord;

/**
 * Model for club facilities
 * @property string $club
 * @property string $facility
 */
class Facility extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['club', 'facility'], 'required'],
			[['club', 'facility'], 'string']
		];
	}
}