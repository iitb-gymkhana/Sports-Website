<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_user_contact`.
 */
class m181018_060321_create_user_contacts_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_user_contact', [
            'ldap' => $this->string()->notNull(),
            'mobile' => $this->bigInteger()->notNull()
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_user_contact', ['ldap', 'mobile']);

        $this->addForeignKey(
            'fk-user_contacts_ldap-event',
            'api_user_contact', 'ldap',
            'api_users', 'ldap',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-user_contacts_ldap-event',
            'api_user_contact'
        );

        $this->dropTable('api_user_contact');
    }
}
