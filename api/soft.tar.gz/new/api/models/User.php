<?php
namespace api\models;

use api\models\Admin;

/**
 * Extension of \yii\web\User to include an "isAdmin" property
 */
class User extends \yii\web\User
{
    /**
     * Returns a value indicating whether the user is an admin (not authenticated).
     * @return bool whether the current user is an admin.
     * @see getIsGuest()
     */
    public function getIsAdmin()
    {
        $identity = $this->getIdentity();
        if($identity === null)
            return false;
        
        return Admin::findOne($identity->id) !== null;
    }
}
