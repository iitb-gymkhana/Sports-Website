<?php
namespace api\components;

use yii\authclient\OAuth2;

/**
 * Custom auth client to connect with Gymkhana SSO, IITB
 */
class SSO extends OAuth2
{
	/**
 	* {@inheritdoc}
 	*/
 	public $autoRefreshAccessToken = true;

    /**
 	* {@inheritdoc}
 	*/
 	public $authUrl = 'http://localhost/~canister/oauth/authorize.php';

    /**
 	* {@inheritdoc}
 	*/
 	public $tokenUrl = 'http://localhost/~canister/oauth/token.php';

    /**
 	* {@inheritdoc}
 	*/
 	public $apiBaseUrl = 'http://localhost/~canister/oauth/resource.php';

    /**
 	* {@inheritdoc}
 	*/
 	public $scope = 'basic profile sex ldap phone insti_address program secondary_emails';
    
    /**
 	* {@inheritdoc}
 	*/
 	protected function initUserAttributes()
    {
    	$resources = [
    		'first_name', 'last_name', 'type',
    		'sex', 'username', 'program', 'email',
    		'insti_address', 'mobile', 'roll_number',
    		'contacts', 'secondary_emails'
    	];
    	$response = $this->createApiRequest()
        	->setMethod('GET')
        	->setUrl($this->apiBaseUrl)
        	->setData(['fields' => implode(',', $resources)])
        	->send();

        if(!$response->isOk)
        	throw new \yii\web\ServerErrorHttpException('Unable to get user resources from SSO');

        return $response->data;
    }
}