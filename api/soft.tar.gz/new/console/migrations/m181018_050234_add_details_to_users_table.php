<?php

use yii\db\Migration;

/**
 * Handles the creation of table `user_details`.
 */
class m181018_050234_add_details_to_users_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('api_users', 'first_name', $this->string()->notNull());
        $this->addColumn('api_users', 'last_name', $this->string());
        $this->addColumn('api_users', 'sex', $this->string()->notNull());
        $this->addColumn('api_users', 'type', $this->string()->notNull());
        $this->addColumn('api_users', 'username', $this->string());
        $this->addColumn('api_users', 'hostel', $this->string(6));
        $this->addColumn('api_users', 'graduation_year', $this->integer(4));
        $this->addColumn('api_users', 'join_year', $this->integer(4));
        $this->addColumn('api_users', 'degree', $this->string());
        $this->addColumn('api_users', 'department', $this->string());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('api_users', 'first_name');
        $this->dropColumn('api_users', 'last_name');
        $this->dropColumn('api_users', 'sex');
        $this->dropColumn('api_users', 'type');
        $this->dropColumn('api_users', 'username');
        $this->dropColumn('api_users', 'hostel');
        $this->dropColumn('api_users', 'graduation_year');
        $this->dropColumn('api_users', 'join_year');
        $this->dropColumn('api_users', 'degree');
        $this->dropColumn('api_users', 'department');
    }
}
