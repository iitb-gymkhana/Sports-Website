<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_ladder_match`.
 */
class m180918_131651_create_ladder_match_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_ladder_match', [
            'match_id' => $this->primaryKey(),
            'challenger' => $this->string()->notNull(),
            'opponent' => $this->string()->notNull(),
            'sport' => $this->string()->notNull(),
            'accepted' => $this->boolean()->defaultValue(null),
            'time' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
        ]);

        // add foreign key for table `ladder_match` to reference `users`
        $this->addForeignKey(
            'fk-ladder_match_challenger-event',
            'api_ladder_match', 'challenger',
            'api_users', 'ldap',
            'CASCADE'
        );

        // add foreign key for table `ladder_match` to reference `users`
        $this->addForeignKey(
            'fk-ladder_match_opponent-event',
            'api_ladder_match', 'opponent',
            'api_users', 'ldap',
            'CASCADE'
        );

        // add foreign key for table `ladder_match` to reference `users`
        $this->addForeignKey(
            'fk-ladder_match_sport-event',
            'api_ladder_match', 'sport',
            'api_ladder_sports', 'club',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-ladder_match_challenger-event',
            'api_ladder_match'
        );

        $this->dropForeignKey(
            'fk-ladder_match_opponent-event',
            'api_ladder_match'
        );

        $this->dropForeignKey(
            'fk-ladder_match_sport-event',
            'api_ladder_match'
        );

        $this->dropTable('api_ladder_match');
    }
}
