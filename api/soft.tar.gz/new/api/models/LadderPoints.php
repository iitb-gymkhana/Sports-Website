<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * Model for ladder ranking system
 * @property string $player player
 * @property string $sport sport
 * @property string $score score of the match
 */
class LadderPoints extends ActiveRecord
{
	// TODO - update the score format

	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['player', 'score', 'sport'], 'required'],
			[['player', 'sport'], 'string'],
			['score', 'integer'],
		];
	}
}