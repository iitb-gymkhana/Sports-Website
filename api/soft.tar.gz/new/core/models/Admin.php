<?php

namespace core\models;

use yii\db\ActiveRecord;

/**
 * Model for admin
 * List of people granted admin rights
 * (123456789, sport) and (sport, sport) both should be in the table - left column is primary key (LDAP)
 *
 * @property string $adminLdap
 * @property string $ldap
 */
class Admin extends ActiveRecord
{
	/**
	 * Update the admin table according to the data in the council table
	 * The council data extracted will be according to the date argument, which defaults to the system time
	 * Only allow Technical Head and G. Sec. to access this function
	 *
	 * @param core\models\User $user User accessing this function
	 * @param date $date Which year's council
	 */
	public static function update($user, $date = null)
	{

	}
}