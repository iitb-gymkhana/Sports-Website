<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_users`.
 */
class m180918_130734_create_users_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_users', [
            'ldap' => $this->string(),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_users', 'ldap');

        $this->batchInsert('api_users', ['ldap'], [
            ['aquatics'],
            ['athletics'],
            ['badminton'],
            ['basketball'],
            ['boardgames'],
            ['cricket'],
            ['football'],
            ['hockey'],
            ['indiangames'],
            ['lawntennis'],
            ['squash'],
            ['tabletennis'],
            ['volleyball'],
            ['weightlifting'],
            ['gsecsports'],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('api_users');
    }
}
