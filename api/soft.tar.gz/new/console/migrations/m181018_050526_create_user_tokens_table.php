<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_user_tokens`.
 */
class m181018_050526_create_user_tokens_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_user_tokens', [
            'ldap' => $this->string(),
            'access_token' => $this->string(),
            'refresh_token' => $this->string(),
            'created_at' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
            'expires_in' => $this->integer()->defaultValue(3600),
            'scope' => $this->string(),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_user_tokens', ['ldap', 'access_token']);

        $this->addForeignKey(
            'fk-user_tokens_ldap-event',
            'api_user_tokens', 'ldap',
            'api_users', 'ldap',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-user_tokens_ldap-event',
            'api_user_tokens'
        );

        $this->dropTable('api_user_tokens');
    }
}
