<?php
return [
    'adminEmail' => 'gsecsport@iitb.ac.in',
    'supportEmail' => 'gsecsport@iitb.ac.in',
    'user.passwordResetTokenExpire' => 3600,
    'session' => 2018
];
