<?php

require_once(__DIR__.'/../../common/config/functions.php');

$params = array_merge(
    require __DIR__ . '/../../common/config/params.php'
);

$components = array_merge(
    require __DIR__ . '/components.php'
);

return [
    'id' => 'core',
    'name' => 'IIT Bombay Sports',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'aliases' => [],
    'controllerNamespace' => 'core\controllers',
    //'catchAll' => ['error'],
    'components' => $components,
    'params' => $params,
];
