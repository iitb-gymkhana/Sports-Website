<?php

namespace api\models;

use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;
use yii\web\ForbiddenHttpException;

/**
 * Model for ladder ranking system
 * @property integer $match_id id of the match
 * @property string $winner winner of the match (challenger/opponent)
 * @property string $score score of the match
 * @property string $time time when match score was recorded
 * @property boolean $winner_confirmation whether result accepted by winner
 * @property boolean $loser_confirmation whether result accepted by loser
 */
class LadderResult extends ActiveRecord
{
	// TODO - update the score format

	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['match_id', 'winner', 'score'], 'required'],
			[['winner', 'score'], 'string'],
			['winner', 'in', 'range' => ['challenger', 'opponent']],
			[['match_id'], 'integer'],
			[['winner_confirmation', 'loser_confirmation'], 'boolean'],
			[['winner_confirmation', 'loser_confirmation'], 'default', 'value' => null],
		];
	}

	/**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::className(),
                'attributes' => [ ActiveRecord::EVENT_BEFORE_INSERT => ['time'] ],
	            'value' => new \yii\db\Expression('NOW()'),
            ],
        ];
    }

	/**
	 * @inheritdoc
	 */
	public function save($runValidation = true, $attributeNames = null)
	{
		$match = \api\models\LadderMatch::findOne($this->match_id);
		$winner = $this->winner === 'challenger' ? $match->challenger : $match->opponent;
		$loser = $this->winner === 'challenger' ? $match->opponent : $match->challenger;

		// Inserting a new record
	    if ($this->getIsNewRecord()) {
	    	$matches = LadderResult::findAll(['match_id' => $this->match_id]);

	    	// Check whether a confirmed match result already exists
            $filter = array_filter($matches, function($instance, $key) {
                return $instance->winner_confirmation && $instance->loser_confirmation;
            }, ARRAY_FILTER_USE_BOTH);
            if(sizeof($filter) > 0)
                throw new ForbiddenHttpException("Match result have already been uploaded and confirmed");

            // Check whether a pending match result already exists
            $filter = array_filter($matches, function($instance, $key) {
                return $instance->winner_confirmation == null || $instance->loser_confirmation == null;
            }, ARRAY_FILTER_USE_BOTH);
            if(sizeof($filter) > 0)
                throw new ConflictHttpException("There are pending match results. Please resolve them first.");

	    	// Don't allow the winner to set the 'loser_confirmation' field
	    	if(\Yii::$app->user->id === $winner) {
	    		unset($this->loser_confirmation);
	    		$this->winner_confirmation = true;
	    	}

	    	// Don't allow the loser to set the 'winner_confirmation' field
	    	else if(\Yii::$app->user->id === $loser) {
	    		unset($this->winner_confirmation);
	    		$this->loser_confirmation = true;
	    	}

	        return $this->insert($runValidation, $attributeNames);
	    } 
	    // Updating an old record
	    else {
	    	if(\Yii::$app->user->id === $winner) {
	    		// Winner cannot modify more than 2 fields or set the 'loser_confirmation' field
	    		if(sizeof($this->dirtyAttributes) > 1 || isset($this->dirtyAttributes['loser_confirmation']))
	    			throw new ConflictHttpException("You can only accept/reject the match result");

	    		// Winner can only accept/reject the result if the entry was made by the loser
	    		if(isset($this->loser_confirmation) && !isset($this->dirtyAttributes['winner_confirmation']))
	    			throw new ForbiddenHttpException("Reject the result and create your own entry if you want to modify the match result details");

	    		// Winner can only modify the score if the entry was made by the winner
	    		if(!isset($this->loser_confirmation) && !isset($this->dirtyAttributes['score']))
	    			throw new ConflictHttpException("You can only modify the scoreline");
	    	}
	    	// Don't allow the loser to set the 'winner_acceptance' field
	    	else if(\Yii::$app->user->id === $loser) {
	    		// Loser cannot modify more than 2 fields or set the 'winner_confirmation' field
	    		if(sizeof($this->dirtyAttributes) > 1 || isset($this->dirtyAttributes['winner_confirmation']))
	    			throw new ConflictHttpException("You can only accept/reject the match result");

	    		// Loser can only accept/reject the result if the entry was made by the winner
	    		if(isset($this->winner_confirmation) && !isset($this->dirtyAttributes['loser_confirmation']))
	    			throw new ForbiddenHttpException("Reject the result and create your own entry if you want to modify the match result details");

	    		// Loser can only modify the score if the entry was made by the loser
	    		if(!isset($this->winner_confirmation) && !isset($this->dirtyAttributes['score']))
	    			throw new ConflictHttpException("You can only modify the scoreline");
	    	}
	    	return $this->update($runValidation, $attributeNames) !== false;
	    }
	}
}