<?php
namespace core\controllers;

use Yii;
use yii\base\Action;
use yii\base\Controller;
use yii\web\ErrorHandler;

/**
 * Error controller
 */
class ErrorController extends Controller
{
	public function actions(){
		return [
			'index' => 'core\controllers\ErrorAction'
		];
	}
}

/**
 * Error response for API
 */
class ErrorAction extends Action
{
    public function run()
    {
        throw new yii\web\InvalidHTTPRequest;
    }
}
