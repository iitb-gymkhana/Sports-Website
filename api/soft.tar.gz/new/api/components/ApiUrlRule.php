<?php
namespace api\components;

use yii\rest\UrlRule;

/**
 * Custom URL rule class to implement ApiRestController functionality
 * 
 * @see api\components\ApiRestController
 */
class ApiUrlRule extends UrlRule
{
	/**
	 * {@inheritdoc}. Allow alphanumeric 'id' token, along with ',' for composite 
	 * primary key matching, required in yii\rest\ActiveController and hence 
	 * api\components\ApiRestController.
	 *
	 * Example - {``` GET name/Franklin,Jones ```}
	 *
	 */
	public $tokens = ['{id}' => '<id:[A-Za-z0-9,-]+>'];

	/**
	* {@inheritdoc}. Add 'filter' path to patterns for ApiRestController
	*
	* @see api\components\ApiRestController
	*/
	public $patterns = [
		'POST filter' => 'index',
        'PUT,PATCH {id}' => 'update',
        'DELETE {id}' => 'delete',
        'GET,HEAD {id}' => 'view',
        'POST' => 'create',
        'GET,HEAD' => 'index',
        '{id}' => 'options',
        '' => 'options',
    ];
}