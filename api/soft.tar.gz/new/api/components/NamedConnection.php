<?php

namespace api\components;
use yii\db\Connection;

/**
 * Custom Connection class to store additional information
 */
class NamedConnection extends Connection
{
	/**
	 * stores name of database for accessibility purposes
	 * @var string name of database
	 */
	public $dbName;
}