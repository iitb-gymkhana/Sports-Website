<?php

namespace api\models;

use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;
use yii\web\ConflictHttpException;

/**
 * Model for ladder ranking system
 * @property integer $match_id id of the match
 * @property string $challenger challenger
 * @property string $opponent user whom opponent challenged
 * @property string $sport which sport 
 * @property boolean $accepted whether accepted the challenge - null if not set yet, true if accepted
 * @property string $time time when challenge was sent
 */
class LadderMatch extends ActiveRecord
{
	// TODO - update the score format

	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['challenger', 'opponent', 'sport'], 'required'],
			[['challenger', 'opponent', 'sport'], 'string'],
			[['match_id'], 'integer'],
			[['accepted'], 'boolean'],
			['accepted', 'default', 'value' => null],
		];
	}

	/**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::className(),
                'attributes' => [ ActiveRecord::EVENT_BEFORE_INSERT => ['time'] ],
	            'value' => new \yii\db\Expression('NOW()'),
            ],
        ];
    }

    /**
	 * @inheritdoc
	 */
	public function save($runValidation = true, $attributeNames = null)
	{
	    if ($this->getIsNewRecord()) {
	    	// Don't allow the challenger to set the 'accepted' field
	    	unset($this->accepted);
	        return $this->insert($runValidation, $attributeNames);
	    } else {
	    	// If the modifier is the challenger, allowed field for modification is 'sport'
	    	if(\Yii::$app->user->id === $this->oldAttributes['challenger']){
	    		if(sizeof($this->dirtyAttributes) > 1)
	    			throw new ConflictHttpException("You can only modify the sport field");
	    		if(sizeof($this->dirtyAttributes) == 1 && !isset($this->dirtyAttributes['sport']))
	    			throw new ConflictHttpException("You can only modify the sport field");
	    	}
	    	// If the modifier is the opponent, allowed field for modification is 'accepted'
	    	else {
	    		if(sizeof($this->dirtyAttributes) > 1)
	    			throw new ConflictHttpException("You can only accept/reject the match request");
	    		if(sizeof($this->dirtyAttributes) == 1 && !isset($this->dirtyAttributes['accepted']))
	    			throw new ConflictHttpException("You can only accept/reject the match request");
	    	}
	        return $this->update($runValidation, $attributeNames) !== false;
	    }
	}
}