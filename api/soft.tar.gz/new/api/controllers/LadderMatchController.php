<?php

namespace api\controllers;

use Yii;
use api\components\ApiRestController;
use yii\web\ForbiddenHttpException;

/**
 * Controller for the club model
 */
class LadderMatchController extends ApiRestController
{
    /**
     * @var yii\db\ActiveRecord model for storing ladder match information
     */
    public $modelClass = 'api\models\LadderMatch';
    
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        $behaviors = parent::behaviors();
        $behaviors['authenticator']['except'] = ['index', 'view', 'options'];
        $behaviors['access']['rules'] = [
            ['allow' => true, 'actions' => ['index', 'view', 'options'], 'roles' => ['?']],
            ['allow' => true,  'roles' => ['@']],
        ];
        return $behaviors;
    }

    /**
     * {@inheritdoc}
     */
    public function checkAccess($action, $model = null, $params = [])
    {
        // Allow all actions for admins
        if(Yii::$app->user->isAdmin)    return;

        // Allow only players to add a match
        if($action === 'create') {
            $newModel = Yii::$app->getRequest()->getBodyParams();
            if(Yii::$app->user->id !== $newModel['challenger'] && Yii::$app->user->id !== $newModel['opponent'])
                throw new ForbiddenHttpException("Players are allowed to create only their own matches");
        }

        // Allow only the first update by the opponent
        if($action === 'update') {
            if(Yii::$app->user->id !== $model->opponent)
                throw new ForbiddenHttpException("Only opponent can accept/reject match");

            if($model->accepted !== null)
                throw new ForbiddenHttpException(sprintf("Match has been %s by the opponent", $model->accepted ? "accepted" : "rejected"));
        }

        // Only admins are allowed delete operations
        if($action === 'delete') {
            if(Yii::$app->user->id !== $model->challenger)
                throw new ForbiddenHttpException("Only challenger and admins are allowed to delete a match request");

            if($model->accepted !== null)
                throw new ConflictHttpException("Match request has already been accepted by your opponent. Contact the administrator to resolve this issue.");
        }
    }
}
