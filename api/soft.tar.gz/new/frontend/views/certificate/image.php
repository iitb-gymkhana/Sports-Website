<?php
use yii\helpers\Html
?>

<?=
Html::img($path, [ 'style' => 'height: 300px'])
?>
<figcaption>
<br><h5><?= $name ?></h5>
</figcaption>