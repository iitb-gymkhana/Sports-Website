<?php

return array_merge(
	[
	    'class' => 'api\components\NamedConnection',
	    'dbName' => 'iitb_sports',
	    'dsn' => 'mysql:host=127.0.0.1;dbname=iitb_sports',
	    'tablePrefix' => 'api_'
	],
	require __DIR__ . '/database-login.php'
);