<?php

namespace api\controllers;

use api\components\ApiRestController;

/**
 * Controller for the club model
 */
class ClubController extends ApiRestController
{
    /**
     * {@inheritdoc}
     */
    public $modelClass = 'api\models\Club';

    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
    	$behaviors = parent::behaviors();
    	$behaviors['authenticator']['except'] = ['index', 'view', 'options'];
        $behaviors['access']['rules'] = [['allow' => true, 'roles' => ['?']]];
        return $behaviors;
    }
    
    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        $actions = parent::actions();
        // disable [create, update and delete] actions
        unset($actions['create'], $actions['update'], $actions['delete']);

        return $actions;
    }
}
