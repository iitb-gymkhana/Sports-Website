<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * Model for sports clubs
 * @property string $id
 * @property string $name
 * @property string $secretary
 */
class Club extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['id', 'name'], 'required'],
			[['id', 'name', 'secretary'], 'string']
		];
	}
}