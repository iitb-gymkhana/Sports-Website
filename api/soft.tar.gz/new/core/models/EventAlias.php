<?php

namespace core\models;

use yii\db\ActiveRecord;
use Event;

/**
 * Model for old sports events which have been rebranded or discontinued
 * @property string $fomerId
 * @property string $id
 */
class EventAlias extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['id'], 'default', 'value' => null],	// set id to null by default
			[['formerId'], 'required'],
			[['formerId', 'id'], 'string'],
			[['id'], function($id, $params, $validator){
				// if the id is not null, it has to be an active event
				if($id != null)
					if(Event::findOne($id) == null)
						$validator->addError($this, $attribute, 'Attribute {attribute} has value {value} which is either now a discontinued event or was never an event');
			}]
		];
	}

	public static function tableName()
	{
		return 'event_alias';
	}
}