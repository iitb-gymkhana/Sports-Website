<?php

namespace core\models;

use yii\db\ActiveRecord;
use Event;

/**
 * Mapping between events and clubs
 * @property string $event
 * @property string $club
 */
class EventClubAssociation extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['event', 'club'], 'required'],
		];
	}

	/**
	 * @inheritdoc
	 */
	public static function tableName()
	{
		return 'event_club_association';
	}
}