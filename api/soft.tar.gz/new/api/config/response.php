<?php

return [
	// Output format
	'format' => \yii\web\Response::FORMAT_JSON,

	// Formatter (convert data to content)
    'formatters' => [
        \yii\web\Response::FORMAT_JSON => [
            'class' => 'yii\web\JsonResponseFormatter',
            'prettyPrint' => YII_DEBUG, 					// use "pretty" output in debug mode
        ]
    ],

    // Before Send event for response
    'on beforeSend' => function($event) {
    	$response = $event->sender;
    	if($response->data !== null) {
    		if(!$response->isSuccessful && !YII_DEBUG) {
    			unset($response->data["type"], $response->data["previous"]);
    		}
    		$response->data = [								// Format response to envelope data inside "data"
    			'status' => $response->isSuccessful,		// and include a "status" key in messages
    			'data' => $response->data
    		];
    	}
    }
];