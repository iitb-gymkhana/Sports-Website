<?php

return [
	[
		'class' => 'api\components\ApiUrlRule',
		'controller' => 'club',
		'except' => ['delete', 'create', 'update']
	],
	[
		'pattern' => 'test',
		'route' => 'site/test'
	],
	[
		'class' => 'api\components\ApiUrlRule',
		'controller' => ['match' => 'ladder-match'],
		'prefix' => 'ladder',
	],
	[
		'class' => 'api\components\ApiUrlRule',
		'controller' => ['result' => 'ladder-result'],
		'prefix' => 'ladder',
	],
	[
		'class' => 'yii\web\GroupUrlRule',
		'prefix' => 'authorize',
		'rules' => [
			'sso' => 'index',
			'status' => 'status',
			'refresh' => 'refresh'
		]
	],
	[
		'class' => 'api\components\ApiUrlRule',
		'controller' => 'user',
		'except' => ['delete', 'create'],
		'extraPatterns' => [
			'GET privelege-level' => 'privelege-level'
		]
	],
];