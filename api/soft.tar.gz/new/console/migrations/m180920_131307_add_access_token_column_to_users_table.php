<?php

use yii\db\Migration;

/**
 * Handles adding access_token to table `api_users`.
 */
class m180920_131307_add_access_token_column_to_users_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('api_users', 'access_token', $this->string()->unique());
        $this->addColumn('api_users', 'created_at', $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'));
        $this->addColumn('api_users', 'updated_at', $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('api_users', 'access_token');
        $this->dropColumn('api_users', 'created_at');
        $this->dropColumn('api_users', 'updated_at');
    }
}
