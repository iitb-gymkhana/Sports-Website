<?php

namespace core\models

use yii\db\ActiveRecord;

/**
 * Model for club roster
 * @property string $club club
 * @property string $sport sport
 * @property string $ldap LDAP
 * @property string $year year
 * @property string $position captain, vice-captain, coach, secretary etc.
 * @property integer $order order of listing (1 for top)
 */
class Roster extends ActiveRecord
{
	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['club', 'sport', 'year', 'ldap', 'order'], 'required'],
			[['order'], 'default', 'value' => 1],
			[['year'], 'default', 'value' => \Yii::$app->session],
			[['position'], 'range', 'in' => [
				'Captain',
				'Vice-Captain',
				'Coach',
				'Secretary'
			]]
		];
	}
}