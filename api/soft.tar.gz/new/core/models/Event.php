<?php

namespace core\models;

use yii\db\ActiveRecord;

/**
 * Model for sports events
 * @property string $id
 * @property string $type either competitive or non-competitive
 */
class Event extends ActiveRecord
{
	const TYPE_COMPETITIVE = 'competitive';
	const TYPE_NONCOMPETITIVE = 'non-competitive';

	/**
	 * @inheritdoc
	 */
	public function rules()
	{
		return [
			[['id', 'type'], 'required'],
			[['id'], 'string'],
			[['type'], 'in', 'range' => [self::TYPE_NONCOMPETITIVE, self::TYPE_COMPETITIVE]]
		];
	}
}