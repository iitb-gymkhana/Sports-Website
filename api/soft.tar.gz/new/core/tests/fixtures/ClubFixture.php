<?php
namespace api\tests\fixtures;

use yii\test\ActiveFixture;

/**
 * Fixture for the club model. Run the fixture using
 * fixture/load --namespace "api\tests\fixtures" Club
 */
class ClubFixture extends ActiveFixture
{
    public $modelClass = 'api\models\Club';
}