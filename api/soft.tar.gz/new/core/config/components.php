<?php

$urlRules = array_merge(
    require __DIR__ . '/url-rules.php'
);

$db = require __DIR__ . '/database.php';

return array_merge($db, [
	'request' => [
        'csrfParam' => '_csrf-api',
    ],
    'db' => $db,
    'user' => [
        'identityClass' => 'common\models\User',
    ],
    // 'session' => [
    //     // this is the name of the session cookie used for login on the frontend
    //     'name' => 'advanced-api',
    // ],
    'log' => [
        'traceLevel' => YII_DEBUG ? 3 : 0,
        'targets' => [
            [
                'class' => 'yii\log\FileTarget',
                'levels' => ['error', 'warning'],
            ],
        ],
    ],
    // Change this
    'errorHandler' => [
        'errorAction' => 'error',
    ],
    'urlManager' => [
        'enablePrettyUrl' => true,
        'showScriptName' => false,
        'enableStrictParsing' => false,
        'rules' => $urlRules,
    ],
    'request' => [
        'parsers' => [
            'application/json' => 'yii\web\JsonParser',
        ]
    ]
]);