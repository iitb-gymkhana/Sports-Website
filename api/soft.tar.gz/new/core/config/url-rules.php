<?php

return [
	[
		'class' => 'yii\rest\UrlRule',
		'controller' => 'club',
		'except' => ['delete', 'create', 'update'],
		'tokens' => ['{id}' => '<id:[A-Za-z0-9]+>']
	]
];