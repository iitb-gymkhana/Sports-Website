<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_ladder_result`.
 */
class m180918_132851_create_ladder_result_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_ladder_result', [
            'match_id' => $this->integer()->notNull(),
            // Add a constraint to check winner is 'challenger' or 'opponent'
            'winner' => $this->string()->notNull(),
            'score' => $this->string()->notNull(),
            'time' => $this->dateTime()->defaultExpression('CURRENT_TIMESTAMP'),
            'winner_confirmation' => $this->boolean()->defaultValue(null),
            'loser_confirmation' => $this->boolean()->defaultValue(null),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_ladder_result', ['match_id', 'time']);

        // add foreign key for table `ladder_result` to reference `ladder_match`
        $this->addForeignKey(
            'fk-ladder_result_match_id-event',
            'api_ladder_result', 'match_id',
            'api_ladder_match', 'match_id',
            'CASCADE'
        );
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-ladder_result_match_id-event',
            'api_ladder_result'
        );

        $this->dropTable('api_ladder_result');
    }
}
