<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * User email model
 * Store multiple email addresses of users
 *
 * @property string $ldap LDAP of user
 * @property string $email email id of user
 */
class UserEmail extends ActiveRecord
{
	/**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ldap', 'email'], 'required'],
            [['ldap', 'email'], 'string']
        ];
    }
}