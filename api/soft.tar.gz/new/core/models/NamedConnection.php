<?php

namespace core\models;
use yii\db\Connection;

class NamedConnection extends Connection
{
	public $dbName;
}