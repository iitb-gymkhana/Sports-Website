<?php

use yii\db\Migration;

/**
 * Handles the creation of table `api_club`.
 */
class m180918_130923_create_club_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('api_club', [
            'id' => $this->string(),
            'name' => $this->string()->notNull(),
            'secretary' => $this->string()->notNull(),
        ]);

        $this->addPrimaryKey(\Yii::$app->db->dbName, 'api_club', 'id');

        // add foreign key for table `club` to reference `admin`
        $this->addForeignKey(
            'fk-club_secretary-event',
            'api_club', 'secretary',
            'api_admin', 'ldap',
            'CASCADE'
        );

        // pre-fill table with some values
        $this->batchInsert('api_club', ['id', 'name', 'secretary'], [
            ['aquatics', 'Aquatics', 'aquatics'],
            ['athletics', 'Athletics', 'athletics'],
            ['badminton', 'Badminton', 'badminton'],
            ['basketball', 'Basketball', 'basketball'],
            ['boardgames', 'Indian Board Games', 'boardgames'],
            ['cricket', 'Cricket', 'cricket'],
            ['football', 'Football', 'football'],
            ['hockey', 'Hockey', 'hockey'],
            ['indiangames', 'Indian Games', 'indiangames'],
            ['lawntennis', 'Lawn Tennis', 'lawntennis'],
            ['squash', 'Squash', 'squash'],
            ['tabletennis', 'Table Tennis', 'tabletennis'],
            ['volleyball', 'Volleyball', 'volleyball'],
            ['weightlifting', 'Weightlifting', 'weightlifting'],
        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKey(
            'fk-club_secretary-event',
            'api_club'
        );

        $this->dropTable('api_club');
    }
}
