<?php
namespace api\controllers;

use yii\web\Controller;
use api\components\AuthHandler;
use yii\filters\ContentNegotiator;
use yii\web\Response;

/**
 * Controller for the club model
 */
class AuthorizeController extends Controller
{
    public function behaviors()
    {
        $contentNegotiator = [
            'class' => ContentNegotiator::className(),
            'formats' => ['application/json' => Response::FORMAT_JSON],
        ];

        $behaviors = parent::behaviors();
        $behaviors['contentNegotiator'] = $contentNegotiator;

        return $behaviors;
    }
    /**
     * {@inheritdoc}
     */
    public function actions()
    {
        $actions = parent::actions();
        return array_merge(
            $actions,
            [
                'index' => [
                    'class' => 'yii\authclient\AuthAction',
                    'cancelCallback' => [$this, 'cancelCallback'],
                    'successCallback' => [$this, 'successCallback'],
                ]
            ]
        );
    }
    
    /**
     * Get status of access token in authentication header
     */
    public function actionStatus()
    {
        return ['status' => (new \api\models\Token)->getStatus()];
    }

    /**
     * Refresh access token from OAuth server
     */
    public function actionRefresh()
    {
        $newToken = (new \api\models\Token)->refresh();
        if($newToken == null)
            throw new \Exception('Cannot refresh access token. Please login and authorize again');

        return [
            'access_token' => $newToken->access_token,
            'expires_in' => $newToken->expires_in
        ];
    }

    /**
     * Handles cancelled authentication by user via Yii auth component
     */
    public function cancelCallback($client)
    {
        throw new \Exception("Access denied by user");
    }

    /**
     * Handles successful authentication by user via Yii auth component
     */
    public function successCallback($client)
    {
        (new AuthHandler($client))->handle();

        $tokenParams = $client->getAccessToken()->getParams();
        \Yii::$app->response->data = [
            'access_token' => $tokenParams['access_token'],
            'expires_in' => $tokenParams['expires_in']
        ];
        return \Yii::$app->response;
    }
}