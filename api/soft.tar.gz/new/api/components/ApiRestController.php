<?php
namespace api\components;

use yii\rest\ActiveController;
use yii\filters\auth\HttpBearerAuth;
use yii\filters\AccessControl;
use yii\filters\ContentNegotiator;
use yii\web\Response;

/**
 * ApiRestController
 * Standard controller class for API application which extends ActiveController
 *
 * Includes a serialiser for the output. Authenticates using yii\filters\auth\HttpBearerAuth
 * and uses yii\filters\AccessControl. Modify behavior in instances of ApiController to
 * exempt actions from authentication and add rules for access control
 */
class ApiRestController extends ActiveController
{
	/**
     * {@inheritdoc}
     *
     * Collect data items under the 'item' envelope
     */
    public $serializer = [
        'class' => 'yii\rest\Serializer',
        'collectionEnvelope' => 'items',
    ];

	/**
     * {@inheritdoc}. Added authenticator and access controls to the controller, 
     * whose rules need to explicitly specified in the instances of ApiRestController.
     *
     * Example:
     * ```
     *	$behaviors = parent::behaviors();
     *	$behaviors['access']['rules'] = [
     *		// add custom rules (instance of yii\filters\AccessRule) here ...
     *		['allow' => false, 'ips' => '10.3.*'],
     *		// you can also use custom classes
     *	];
     *	$behaviors['authenticator'] = [
     *		// add custom authenticator properties here ...
     *	];
     * ```
	 *
	 * @see yii\filters\AccessRule
	 * @see yii\filters\auth\HttpBearerAuth
     */
    public function behaviors()
	{
		$behaviors = parent::behaviors();
		$access = [
			'class' => AccessControl::className(),
			'denyCallback' => function ($rule, $action) {
                throw new \Exception('Insufficient priveleges to access this page');
            },

			/* Modify this parameter in the instance
			 * Array of yii\filters\AccessRule - configure access control rules
			 */
			'rules' => [['allow' => true, 'roles' => ['@']]],
		];

		$authenticator = [
			'class' => HttpBearerAuth::className(),
			
			/* Modify this parameter in the instance
			 * Array of action IDs exempt from authentication
			 */
			'except' => [],
			
			/* Modify this parameter in the instance
			 * Array of action IDs which are to be executed irregardless of authentication failure
			 */
			'optional' => [],
		];

		$contentNegotiator = [
            'class' => ContentNegotiator::className(),
            'formats' => ['application/json' => Response::FORMAT_JSON],
        ];

        $behaviors = parent::behaviors();
        unset($behaviors['authenticator'], $behaviors['access'], $behaviors['contentNegotiator']);
        // Authenticator behavior should run first
        $behaviors['authenticator'] = $authenticator;
        $behaviors['access'] = $access;
        $behaviors['contentNegotiator'] = $contentNegotiator;
        
        return $behaviors;
	}

	/**
     * {@inheritdoc}. Add a dataFilter property to index controller (yii\reset\IndexAction) to 
     * allow requests for getting filtered data
     *
     * To apply filters, first create corresponding URL rule in application configuration and 
     * allow the corresponding verb through the [[verbs()]] function in controller, if not 
     * already done so. Then, if the URL rule is {```POST filter```}, apply the filter by
     * sending the filter parameters in the body. Example:
     *
     * ```
     *	{
     * 		"or": [
	 *	        {
	 *	            "and": [
	 *	                {
	 *	                    "name": "some name",
	 *	                },
	 *	                {
	 *	                    "price": "25",
	 *	                }
	 *	            ]
	 *	        },
	 *	        {
	 *	            "id": {"in": [2, 5, 9]},
	 *	            "price": {
	 *	                "gt": 10,
	 *	                "lt": 50
	 *	            }
	 *	        }
	 *	    ]
	 *	}
	 * ```
     *
     * @see yii\data\ActiveDataFilter
     * @see yii\rest\IndexAction
     */
    public function actions()
	{
		$actions = parent::actions();
		$actions['index']['dataFilter'] = [
			'class' => 'yii\data\ActiveDataFilter',
			'searchModel' => $this->modelClass,
		];
		return $actions;
	}

	/**
	 * {@inheritdoc}. Allow POST to index action for ActiveDataFilter
	 * Also add a 'POST filter' pattern to \yii\rest\URLRule
	 * to allow POST requests (with the filter details in the body) to go through
	 */
	public function verbs()
	{
		$verbs = parent::verbs();
		array_push($verbs['index'], 'POST');
		return $verbs;
	}
}