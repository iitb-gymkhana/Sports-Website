<?php

namespace core\models;

use yii\db\ActiveRecord;
use core\models\Admin;

/**
 * Model for users
 * @property string $ldap
 * @property string $name
 * @property bool $isGuest
 * @property bool $isAdmin
 */
class User extends ActiveRecord
{
	/**
	 * Is the user a guest?
	 */
	public $isGuest = TRUE;
	/**
	 * Is the user an administrator?
	 */
	public $isAdmin = FALSE;
	/**
	 * Corresponding admin LDAP ID if the user is an administrator
	 */
	public $adminLDAP = null;

	/**
	 * Finds User by LDAP ID
	 * Searches for the user and assigns priveleges accordingly
	 *
	 * @param string $ldap LDAP ID of the user
	 */
	public function findByLDAP($ldap)
	{
		$model = User::findOne($ldap);
		if($model == null)
			return null;

		$this = $model;
		$this->isGuest = FALSE;

		$admin = Admin::findOne($id);
		if($admin != null){
			$this->isAdmin = TRUE;
			$this->adminLDAP = $admin->adminLdap;
		}

		return $this;
	}
}