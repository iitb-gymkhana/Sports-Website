<?php

namespace api\models;

use yii\db\ActiveRecord;

/**
 * Token model
 * OAuth2.0 Token
 *
 * @property string $ldap LDAP of user
 * @property string $first_name first name of user
 * @property string $last_name last name of user
 * @property string $sex gender of user
 * @property string $type type of user. eg- faculty, ug, staff
 * @property string $username ldap username
 * @property string $hostel hostel of user
 * @property integer $graduation_year year when user graduates
 * @property integer $join_year year when user joined institute
 * @property string $degree degree which user is pursuing
 * @property string $department department in which user is enrolled
 */
class UserDetail extends ActiveRecord
{
	/**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['ldap', 'first_name', 'last_name', 'sex', 'type', 'username', 'hostel', 'degree', 'department'], 'string'],
            [['ldap', 'first_name', 'last_name', 'type', 'sex', 'department'], 'required'],
            [['graduation_year', 'join_year'], 'integer']
        ];
    }

    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
    	return '{{%users}}';
    }
}